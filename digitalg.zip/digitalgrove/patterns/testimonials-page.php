<?php
/**
 * Title: Testimonials page
 * Slug: digitalgrove/testimonials-page
 * Categories: digitalgrove
 * Keywords: testimonials
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"digitalgrove/testimonials"} /-->
<!-- wp:pattern {"slug":"digitalgrove/testimonials-two"} /-->
<!-- wp:pattern {"slug":"digitalgrove/articles"} /-->
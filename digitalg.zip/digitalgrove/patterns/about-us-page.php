<?php
/**
 * Title: About Us Page
 * Slug: digitalgrove/about-us-page
 * Categories: digitalgrove
 * Keywords: about-us
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"digitalgrove/about-us"} /-->
<!-- wp:pattern {"slug":"digitalgrove/about-us-two"} /-->
<!-- wp:pattern {"slug":"digitalgrove/about-us-three"} /-->
<?php
/**
 * Title: Services Page
 * Slug: digitalgrove/services-page
 * Categories: digitalgrove
 * Keywords: services
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"digitalgrove/services"} /-->
<!-- wp:pattern {"slug":"digitalgrove/portfolio"} /-->
<!-- wp:pattern {"slug":"digitalgrove/services-two"} /-->